import React from 'react'
import TopNavbar from './TopNavbar'

const WorkCenterCreate = () => {
  return (
    <div>
      <TopNavbar />
      Create Work Center
    </div>
  )
}

export default WorkCenterCreate
