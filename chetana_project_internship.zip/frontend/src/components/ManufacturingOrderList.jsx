import React from 'react'
import TopNavbar from './TopNavbar'

const ManufacturingOrderList = () => {
  return (
    <div>
      <TopNavbar />
      List of all Manufacturing Orders
    </div>
  )
}

export default ManufacturingOrderList
