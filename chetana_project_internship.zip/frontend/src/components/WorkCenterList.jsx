import React from 'react'
import TopNavbar from './TopNavbar'

const WorkCenterList = () => {
  return (
    <div>
      <TopNavbar />
      Create Work Center
    </div>
  )
}

export default WorkCenterList
